package com.rahmananda.listmovie.network;

import com.rahmananda.listmovie.model.ResponseMovie;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {

    @GET("movie/now_playing")
    Call<ResponseMovie> getMovie (@Query("api_key") String apikey,
                                  @Query("languange") String language,
                                  @Query("page") int page);
}
