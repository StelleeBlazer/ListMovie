package com.rahmananda.listmovie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Toast;

import com.rahmananda.listmovie.model.ResponseMovie;
import com.rahmananda.listmovie.model.ResultsItem;
import com.rahmananda.listmovie.network.ApiClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    //deklarasi
    private RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //inialisasi
        rv = findViewById(R.id.rv_movie);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        String apiKey = "0a1f74d199031612733f5a747743e203";
        String languange = "en-US";
        int page = 1;

        final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
        dialog.setCancelable(false);
        dialog.setMessage("Loading....");
        dialog.show();

        ApiClient.service.getMovie(apiKey,languange,page).enqueue(new Callback<ResponseMovie>() {
            @Override
            public void onResponse(Call<ResponseMovie> call, Response<ResponseMovie> response) {
                if (response.isSuccessful()){
                    dialog.dismiss();

                    ResponseMovie movie = response.body();
                    List<ResultsItem> resultsItems = movie.getResults();

                    MovieAdapter adapter = new MovieAdapter(resultsItems, MainActivity.this);
                    adapter.notifyDataSetChanged();

                    rv.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<ResponseMovie> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
}
