package com.rahmananda.listmovie;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rahmananda.listmovie.model.ResultsItem;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolderMovie> {
    //1 deklarasi
    private List<ResultsItem> resultsItems;
    private Context context;

    //2 constructor
    public MovieAdapter(List<ResultsItem> resultsItems, Context context){
        this.resultsItems = resultsItems;
        this.context = context;
    }


    //3 panggil layout
    @NonNull
    @Override
    public MovieAdapter.ViewHolderMovie onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_movie,parent, false);
        return new ViewHolderMovie(view);
    }

    //5 get data ynag akan ditampilkan
    @Override
    public void onBindViewHolder(@NonNull MovieAdapter.ViewHolderMovie holder, int position) {
        String poster = resultsItems.get(position).getPosterPath();
        holder.tvJudul.setText(resultsItems.get(position).getTitle());
        holder.tvTanggal.setText(resultsItems.get(position).getTitle());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailMovieActivity.class);
                intent.putExtra("MOVIE",resultsItems.get(position));
                context.startActivity(intent);

            }
        });

        String urlImage = "https://image.tmdb.org/t/p/w500/";
        Glide.with(context).load(urlImage + poster).into(holder.imgMovie);
    }

    //6
    @Override
    public int getItemCount() {
        return resultsItems.size();
    }

    //4 deklarasi dan inialisasi
    public class ViewHolderMovie extends RecyclerView.ViewHolder {

        private ImageView imgMovie;
        private TextView tvJudul, tvTanggal;

        public ViewHolderMovie(@NonNull View itemView) {
            super(itemView);

            imgMovie = itemView.findViewById(R.id.img_movie);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvTanggal = itemView.findViewById(R.id.tv_tanggal);
        }
    }
}


